<html>
<head>
<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript">
swfobject.embedSWF(
"open-flash-chart.swf", "my_chart",
"600", "400", "9.0.0", "expressInstall.swf",
{"data-file":"stacked_data_new.php"} );
</script>
</head>
<body>
<div id="my_chart"></div>
</body>
</html>
